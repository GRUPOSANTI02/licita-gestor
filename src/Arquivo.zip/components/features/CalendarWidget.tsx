"use client";

import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useTenders } from "@/context/TenderContext";

export function CalendarWidget() {
    const { tenders } = useTenders();
    const [currentDate, setCurrentDate] = useState(new Date());

    const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
    const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay();

    const monthName = currentDate.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });

    const getTendersForDay = (day: number) => {
        return tenders.filter(t => {
            const tDate = new Date(t.deadline);
            return tDate.getDate() === day &&
                tDate.getMonth() === currentDate.getMonth() &&
                tDate.getFullYear() === currentDate.getFullYear();
        });
    };

    return (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 overflow-hidden">
            <div className="flex justify-between items-center mb-6 px-2">
                <div>
                    <h2 className="text-xl font-bold text-slate-800 capitalize leading-none">{monthName}</h2>
                    <p className="text-[10px] text-slate-400 mt-1 uppercase tracking-wider font-black">Cronograma de Prazos</p>
                </div>
                <div className="flex gap-2">
                    <button
                        onClick={() => setCurrentDate(new Date(currentDate.setMonth(currentDate.getMonth() - 1)))}
                        className="p-2 hover:bg-slate-100 rounded-lg text-slate-500 transition-colors border border-slate-100"
                    >
                        <ChevronLeft className="w-5 h-5" />
                    </button>
                    <button
                        onClick={() => setCurrentDate(new Date())}
                        className="px-4 py-2 bg-blue-50 text-blue-600 rounded-lg font-bold text-xs transition-colors hover:bg-blue-100 border border-blue-100"
                    >
                        Hoje
                    </button>
                    <button
                        onClick={() => setCurrentDate(new Date(currentDate.setMonth(currentDate.getMonth() + 1)))}
                        className="p-2 hover:bg-slate-100 rounded-lg text-slate-500 transition-colors border border-slate-100"
                    >
                        <ChevronRight className="w-5 h-5" />
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-7 mb-2 border-b border-slate-50 pb-2">
                {['DOM', 'SEG', 'TER', 'QUA', 'QUI', 'SEX', 'SÁB'].map((day, idx) => (
                    <div key={idx} className="text-center text-[10px] font-black text-slate-400">
                        {day}
                    </div>
                ))}
            </div>

            <div className="grid grid-cols-7 gap-1 sm:gap-2">
                {Array.from({ length: firstDay }).map((_, i) => (
                    <div key={`empty-${i}`} className="min-h-[100px] sm:min-h-[120px] bg-slate-50/10 rounded-xl" />
                ))}

                {Array.from({ length: daysInMonth }).map((_, i) => {
                    const day = i + 1;
                    const dayTenders = getTendersForDay(day);
                    const hasTender = dayTenders.length > 0;
                    const isToday = day === new Date().getDate() && currentDate.getMonth() === new Date().getMonth() && currentDate.getFullYear() === new Date().getFullYear();

                    return (
                        <div
                            key={day}
                            className={`
                                min-h-[100px] sm:min-h-[120px] relative flex flex-col p-2 rounded-xl transition-all border
                                ${isToday ? 'border-blue-500 bg-blue-50/20 shadow-sm' : 'border-slate-100 bg-white hover:border-slate-200'}
                                ${hasTender && !isToday ? 'bg-indigo-50/10 border-indigo-100/30' : ''}
                            `}
                        >
                            <span className={`
                                text-sm font-black mb-1 
                                ${isToday ? 'bg-blue-600 text-white w-6 h-6 flex items-center justify-center rounded-lg shadow-md -mt-1.5 -ml-1.5' : 'text-slate-400'}
                            `}>
                                {day}
                            </span>

                            <div className="flex-1 space-y-1 overflow-y-auto custom-scrollbar pr-0.5 mt-1">
                                {dayTenders.map((t, idx) => (
                                    <div
                                        key={idx}
                                        className={`
                                            text-[9px] px-2 py-1 rounded-md border leading-tight font-black uppercase tracking-tighter
                                            ${t.status === 'won' ? 'bg-green-50 border-green-100 text-green-700' :
                                                t.status === 'lost' ? 'bg-red-50 border-red-100 text-red-700' :
                                                    'bg-blue-50 border-blue-100 text-blue-700'}
                                        `}
                                    >
                                        <div className="truncate">{t.title}</div>
                                        {t.tenderNumber && <div className="text-[7px] opacity-60">NR: {t.tenderNumber}</div>}
                                    </div>
                                ))}
                            </div>
                        </div>
                    );
                })}
            </div>

            <div className="mt-6 pt-4 border-t border-slate-50 flex flex-wrap gap-4 text-[10px] font-black uppercase text-slate-400 tracking-widest">
                <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-blue-600"></div> Hoje</div>
                <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-blue-500"></div> Pendente</div>
                <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-green-500"></div> Ganha</div>
                <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-red-500"></div> Perdida</div>
            </div>

            <style jsx>{`
                .custom-scrollbar::-webkit-scrollbar { width: 2px; }
                .custom-scrollbar::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
            `}</style>
        </div>
    );
}
