"use client";

import { TenderCard } from "@/components/features/TenderCard";
import { useTenders } from "@/context/TenderContext";
import { formatCurrency } from "@/lib/utils";
import { ArrowUpRight, TrendingUp, Users, AlertCircle, Plus } from "lucide-react";
import { SalesChart } from "@/components/features/SalesChart";
import { CalendarWidget } from "@/components/features/CalendarWidget";
import Link from "next/link";

export default function Dashboard() {
    const { tenders, isLoading } = useTenders();

    const totalValue = tenders.reduce((acc, t) => acc + t.value, 0);
    const activeTenders = tenders.filter(t => t.status === 'in_progress' || t.status === 'pending').length;
    const wonTenders = tenders.filter(t => t.status === 'won');
    const totalWonRevenue = wonTenders.reduce((acc, t) => acc + (t.wonValue || 0), 0);

    const recentTenders = tenders.slice(0, 2);

    if (isLoading) {
        return (
            <div className="flex h-screen items-center justify-center bg-slate-50">
                <div className="flex flex-col items-center gap-4">
                    <div className="animate-spin rounded-full h-12 w-12 border-4 border-slate-200 border-t-blue-600"></div>
                    <p className="text-sm font-bold text-slate-400 uppercase tracking-widest text-[10px]">LicitaGestor Carregando...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="space-y-10 pb-20">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 text-slate-900">
                <div>
                    <h1 className="text-4xl font-black tracking-tight">Olá, Gestor!</h1>
                    <p className="text-slate-500 font-medium">Aqui estão os seus compromissos para hoje.</p>
                </div>
                <Link
                    href="/tenders/new"
                    className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3.5 rounded-2xl flex items-center gap-3 transition-all transform hover:scale-[1.02] active:scale-[0.98] font-black shadow-2xl shadow-blue-500/30 text-sm uppercase tracking-wider"
                >
                    <Plus className="w-5 h-5" />
                    Nova Licitação
                </Link>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard
                    title="Oportunidades"
                    value={formatCurrency(totalValue)}
                    icon={<TrendingUp className="text-blue-600 w-5 h-5" />}
                    trend="+R$ 45k este mês"
                    trendUp={true}
                />
                <StatCard
                    title="Em Andamento"
                    value={activeTenders.toString()}
                    icon={<AlertCircle className="text-amber-600 w-5 h-5" />}
                    trend="Verificar prazos"
                />
                <StatCard
                    title="Receita Real (Ganhos)"
                    value={formatCurrency(totalWonRevenue)}
                    icon={<ArrowUpRight className="text-green-600 w-5 h-5" />}
                    trend={`${wonTenders.length} arrematadas`}
                    trendUp={true}
                />
                <StatCard
                    title="Taxa de Vitória"
                    value={tenders.length > 0 ? `${Math.round((wonTenders.length / tenders.length) * 100)}%` : "0%"}
                    icon={<Users className="text-purple-600 w-5 h-5" />}
                    trend="Baseado no histórico"
                />
            </div>

            <div className="space-y-6">
                <div className="flex items-center gap-3">
                    <div className="w-1.5 h-8 bg-blue-600 rounded-full"></div>
                    <h2 className="text-2xl font-black text-slate-900 tracking-tight uppercase">Agenda de Disputas</h2>
                </div>
                <CalendarWidget />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
                <div className="lg:col-span-2 space-y-6">
                    <div className="flex justify-between items-center">
                        <h2 className="text-xl font-black text-slate-800 tracking-tight uppercase">Recentes</h2>
                        <Link href="/tenders" className="text-blue-600 text-xs font-black uppercase tracking-widest hover:underline font-bold">
                            Ver Tudo
                        </Link>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {recentTenders.length === 0 ? (
                            <div className="md:col-span-2 p-16 text-center bg-white rounded-3xl border border-dashed border-slate-200">
                                <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">Nenhum dado cadastrado</p>
                            </div>
                        ) : (
                            recentTenders.map((tender) => (
                                <TenderCard key={tender.id} tender={tender} />
                            ))
                        )}
                    </div>
                </div>

                <div className="lg:col-span-1 space-y-6">
                    <div className="flex items-center justify-between">
                        <h2 className="text-xl font-black text-slate-800 tracking-tight uppercase">Análise</h2>
                    </div>
                    <SalesChart />
                </div>
            </div>
        </div>
    );
}

function StatCard({ title, value, icon, trend, trendUp }: any) {
    return (
        <div className="bg-white p-7 rounded-3xl shadow-sm border border-slate-200 hover:shadow-xl transition-all duration-300 group">
            <div className="flex justify-between items-start mb-4">
                <div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">{title}</p>
                    <h3 className="text-2xl font-black text-slate-900 group-hover:text-blue-600 transition-colors">{value}</h3>
                </div>
                <div className="p-4 bg-slate-50 group-hover:bg-blue-50 rounded-2xl transition-colors">
                    {icon}
                </div>
            </div>
            {trend && (
                <div className={`text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5 ${trendUp ? 'text-green-600' : 'text-slate-400'}`}>
                    {trendUp && <ArrowUpRight className="w-3.5 h-3.5" />}
                    {trend}
                </div>
            )}
        </div>
    );
}
